
package com.appcreator.client
object Config{
    const val GITHUB_OWNER=""
    const val GITHUB_REPO=""
    const val GITHUB_PAT=""
}
